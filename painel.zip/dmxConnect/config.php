<?php

$CONFIG_DEBUG = true;
$CONFIG_SECRET_KEY = 'DnO2qGg9BRpi4sh';

