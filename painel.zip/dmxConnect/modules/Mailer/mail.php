<?php
$exports = <<<'JSON'
{
  "name": "mail",
  "module": "mail",
  "action": "setup",
  "options": {
    "host": "smtp.mailtrap.io",
    "port": 587,
    "username": "b1d185cebed222",
    "password": "2d548bafa481c3"
  }
}
JSON;
?>