<?php
// Database Type : "MySQL"
// Database Adapter : "mysql"
$exports = <<<'JSON'
{
    "name": "dados",
    "module": "dbconnector",
    "action": "connect",
    "options": {
        "server": "mysql",
        "connectionString": "mysql:host=nocodehost.com.br;dbname=nocodeho_crm;user=nocodeho_rafael;password=R@fael9814",
        "meta"  : {}
    }
}
JSON;
?>